<?php

	$link=mysqli_connect("localhost", "root","","users");
	
	if(mysqli_connect_error())
	{
		die("Couldnot connect to the database!");
	}

?>