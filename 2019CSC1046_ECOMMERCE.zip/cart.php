<?php
	
	include("connection.php");
	
	$logId="";
	$error="";
	
	if(!isset($_SESSION['id']))
	{
		$_SESSION['id']=$_COOKIE['id'];
	}
	
	$logId=$_SESSION['id'];

			
	$query="SELECT email FROM users WHERE id='".$logId."' LIMIT 1";
			
	$result=mysqli_query($link,$query);
			
	$row= mysqli_fetch_array($result);
	
	$logId=$row['email'];
	
	//echo $logId;
	
	if($_SESSION['id']<0)
	{
		$error="";
		$logId="";
		$logout="";
	
		if(array_key_exists("logout",$_POST))
		{
			unset($_SESSION);
			setcookie("id","",time()-60*60);
			
			$_COOKIE["id"]="";
			
			header("Location: index.php");
			
		}
		
		if(array_key_exists("signUpSubmit",$_POST))
		{
			
			if(!$_POST['email'])
			{
				$error.="An E-mail Address is Required!<br>";
			}
			if(!$_POST['password'])
			{
				$error.="Password is Required!<br>";
			}
			if(!$_POST['address'])
			{
				$error.="Address is Required!<br>";
			}
			if(!$_POST['address2'])
			{
				$error.="Address is Required!<br>";
			}
			if(!$_POST['city'])
			{
				$error.="City is Required!<br>";
			}
			if(!$_POST['state'])
			{
				$error.="State is Required!<br>";
			}
			if(!$_POST['zip'])
			{
				$error.="Zip is Required!<br>";
			}
			if(!$_POST['role2'])
			{
				$error.="Role is Required!<br>";
			}
			if($error!="")
			{
				$error="<p>There were error(s) in your form:</p>".$error;
			}
			else
			{
				$email=mysqli_real_escape_string($link,$_POST['email']);
				$query="SELECT id FROM users WHERE email='".$email."' LIMIT 1";
				
				$result=mysqli_query($link,$query);
				
				if(mysqli_num_rows($result)>0)
				{
					$error="That email is taken.";
				}else
				{
					$email=mysqli_real_escape_string($link,$_POST['email']);
					$password=mysqli_real_escape_string($link,$_POST['password']);
					$address=mysqli_real_escape_string($link,$_POST['address']);
					$address2=mysqli_real_escape_string($link,$_POST['address2']);
					$city=mysqli_real_escape_string($link,$_POST['city']);
					$state=mysqli_real_escape_string($link,$_POST['state']);
					$zip=mysqli_real_escape_string($link,$_POST['zip']);
					$role=mysqli_real_escape_string($link,$_POST['role2']);
					
					$query="INSERT INTO users (email,password,address,address2,city,state,zip,role) VALUES ('".$email."','".$password."','".$address."','".$address2."','".$city."','".$state."','".$zip."','".$role."')";
					
					if(mysqli_query($link, $query))
					{
						setcookie("id", mysqli_insert_id($link), time()+60*60*24*365);
						
						if(!isset($_COOKIE['id']))
						{
							echo "Cookie is not set";
						}
						else
						{
							echo "Cookie is set";
						}
						$query="UPDATE users SET password='".md5(md5(mysqli_insert_id($link)).$_POST['password'])."'WHERE id=".mysqli_insert_id($link)." LIMIT 1"; 
						//mysqli_insert_id() will the take the id of the inserted row and the md5 it and it would then append to the password they ahve put in, and it wpu;d md5 that and put as the password of the user
						
						mysqli_query($link, $query);
						
						$_SESSION['id']= mysqli_insert_id($link);
						
						$logId=$_SESSION['id'];
					}else
					{
						$error="<p>Could not sign you up please try again later</p>";
					}
				}
			}
		}
		
		
		if(array_key_exists("loginSubmit",$_POST))
		{
			if(!$_POST['email'])
			{
				$error.="An E-mail Address is Required!<br>";
			}
			if(!$_POST['password'])
			{
				$error.="Password is Required!<br>";
			}

			if($error!="")
			{
				$error="<p>There were error(s) in your form:</p>".$error;
			}
			else
			{
				$email=mysqli_real_escape_string($link,$_POST['email']);
				
				$query="SELECT * FROM users WHERE email='".$email."' LIMIT 1";
				
				$result=mysqli_query($link,$query);
				
				$row= mysqli_fetch_array($result);
				
				if(isset($row))
				{
					$hashedPassword=md5(md5($row['id']).$_POST['password']);
					
					//echo $row['password'];
					
					if($hashedPassword == $row['password'])
					{
						$_SESSION['id']=$row['id'];
						setcookie("id", $_SESSION['id'], time()+60*60*24*365);
						if(!isset($_COOKIE['id']))
						{
							echo "Cookie is not set";
						}
						else
						{
							echo "Cookie is set";
							echo $_COOKIE['id'];
						}
						$_SESSION['email']=$row['email'];
						$logId=$_SESSION['email'];
						
					}else
					{
						$error.="Incorrect password<br>";
					}
				}
			
			}
		}
	
	}
	
	if(array_key_exists('searchS',$_POST)) 
	{ 
           $esearch=$_POST['eSearch'];
		   //echo $esearch." searcHED";
		   echo '<script type="text/javascript">alert("Search Pressed");</script>'; 
    } 
	
	include("header.php");
	
	
?>