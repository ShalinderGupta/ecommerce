<?php

	session_start();
	
	include("connection.php");
	
	
	if(array_key_exists('searchS',$_POST)) 
	{ 
           $esearch=$_POST['eSearch'];
		   //echo $esearch." searcHED";
		   echo '<script type="text/javascript">alert("Search Pressed");</script>'; 
    } 
	
	
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">	

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
	
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link href="https://fonts.googleapis.com/css2?family=Dancing+Script&display=swap" rel="stylesheet">
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    
	<style type="text/css">
		body
		{
			background-color:#88BDBC;
			color:#FEFFFF;
			overflow-x:hidden;
		}
		
		navbar
		{
			background-color:#88BDBC;
		} 
		
		.navbar-light .navbar-nav .nav-link
		{
			color:#FEFFFF;
		}
		
		h1
		{
			color:#EDFCEC;
			font-family: 'Dancing Script', cursive;
		}
	
		.tagline
		{
			text-align:center;
		}
		
		#carouselExampleCaptions
		{
			height:400px;
		}
		
		.middle
		{
			margin-left:20px;
			margin-right:20px;
		}
		
		.class-b
		{
			color:#FEFFFF;
			font-weight:bold;
		}
		
		.product-display
		{
			
			margin-left:20px;
			margin-right:20px;
			margin-top:30px;
			<!--border: solid 2px #1C3136;-->
		}
		

		
		.styledBorder
		{
			border: solid 2px #1C3136;
		}
		
		.card-body
		{
			background-color:#88BDBC;
		}
		
		.products
		{
			margin-top:20px;
			margin-left:20px;
		}
		
		.carousel-control-prev
		{
			color:blue;
		}
		
		.aCenter
		{
			text-align:center;
		}
		
		.sButton
		{
			font-size:12px;
		}
		
		.bottom
		{
			margin-top:30px;
			background-color:#112D31;
			margin-right:1px;
		}
		
		.social
		{
			margin-left:20px;
		}
		
		#loginModal
		{
			color:black;
			font-size:10px;
		}
		
		.modal-body
		{
			background-color:#88BDBC;
		}
		
		.modal-header
		{
			background-color:#88BDBC;
		}
		
		.modal-footer
		{
			background-color:#88BDBC;
		}
		
		#signUpForm
		{
			display:none;
		}
		
		.border
		{
			border: 5px solid black;
		}
		
		.displayPName
		{
			background-color:#EDFCEC;
			color:#88BDBC;
			border:none;
		}
		
		</style>
	

	
    <title>E-Commerce</title>
  </head>
  <body>
	<div class="head">
		<nav class="navbar navbar-expand-lg navbar-light">
		  <a class="navbar-brand" href="#">
			<img src="images/relogo.jpg" width="30" height="30">
		  </a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		  </button>

		  <div class="collapse navbar-collapse" id="navbarSupportedContent">
				
			<ul class="navbar-nav mr-auto">
			
			  <li class="nav-item">
				<a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link" href="bikeaccessories.php">Bike Accessories</a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link" href="#">Riding Gears</a>
			  </li>
			  <li class="nav-item">
				<a class="nav-link" href="#">Contact Us</a>
			  </li>
			  <li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" id="navbarDropdown" name="navbarDrowdown" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					<?php 
						if($logId!="")
						{
							echo $logId;
						}
					?>
					</a>
					<div class="dropdown-menu" aria-labelledby="navbarDropdown">
					  <a class="dropdown-item" href="#">My Orders</a>
					  <a class="dropdown-item" href="#">My Wishlist</a>
					  <a class="dropdown-item" href="cart.php">Cart</a>
					  <div class="dropdown-divider"></div>
					  <input type="submit" role="button" id="logout" name="logout" class="dropdown-item" value="Logout">
					</div>
				  </li>
			</ul>
			<form name="searchP" id="searchP" class="form-inline my-2 my-lg-0" method="POST">
			  <input class="form-control mr-sm-2" name="eSearch" type="search" placeholder="Search" aria-label="Search">
			  <input type="submit" id="searchS" name="searchS" class="btn btn-outline-light my-2 my-sm-0 color-white" value="Search">
			  <!--<button name="searchS" class="btn btn-outline-light my-2 my-sm-0 color-white" type="submit">Search</button>
			  -->
			  <!--<input type="submit" name="loginSignUP" style="margin-left:5px;" class="btn btn-outline-light my-2 my-sm-0 color-white" id="loginSignUP" value="Login"> 
			  -->
			  <input type="button" name="loginSignUP" style="margin-left:3px;" id="loginSignUP" data-toggle="modal" data-target="#loginModal" class="btn btn-outline-light my-2 my-sm-0" type="submit" value="Login">
			 
			</form>
			
			
			</ul>
		  </div>
		</nav>
	</div>
	<hr color="#EDFCEC">

	<div id="error">
	<?php 
		if($error!="")
		{
			echo '<div class="row d-flex justify-content-end">
					<div class="col-lg-4 col-sm-4 sol-xs-12 col-md-4">
						<div class="alert alert-warning alert-dismissible fade show" role="alert" >'.$error.'
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button></div>
					</div>
				</div>'; 
		}
	?></div>

		<script type="text/javascript">
		$(".toogleForms").click(function()
		{
				$("#signUpForm").toggle();
				$("#signInForm").toggle();	
		});
		
		$("#navbarDropdown").hide();
		</script>
		
	<div>
	<?php 
		if($logId!="")
		{
			echo '<div class="row d-flex justify-content-end">
					<div class="col-lg-4 col-sm-4 sol-xs-12 col-md-4">
						<div class="alert alert-success alert-dismissible fade show" role="alert" >'.$logId.'
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button></div>
					</div>
				   </div>'; 
	?>

	<script type="text/javascript">
	
		$("#loginSignUP").hide();
		$("#navbarDropdown").show();
		
	</script>
	
	<?php } ?>
	
			
	</div>
	
	<div class="modal fade" id="loginModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="loginModal" aria-hidden="true">
	  <div class="modal-dialog">
		<div class="modal-content">
		  <div class="modal-header">
			<h5 class="modal-title" id="loginModal">Log In/Sign Up</h5>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			  <span aria-hidden="true">&times;</span>
			</button>
		  </div>
		  
		  <div class="modal-body">
		  
			<form id="signInForm" method="POST">
			 
			   <div class="form-group">
				<label for="Role">Role</label>
				<select id="role1" name="role1" class="form-control">
					<option value="Seller">Seller</option>
					<option selected value="Customer">Customer</option>
				</select>
			   </div>
			  
			  <div class="form-group">
				<label for="exampleInputEmail1">Email address</label>
				<input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
				<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
			  </div>
			  <div class="form-group">
				<label for="exampleInputPassword1">Password</label>
				<input name="password" type="password" class="form-control" id="exampleInputPassword1">
			  </div>
			  
			  <input name="loginSubmit" id="loginSubmit" type="submit" class="btn  btn-outline-light sButton" value="Sign In">
			  
			  <input name="forgetPassword" id="forgetPassword" type="submit" class="btn  btn-outline-light sButton" value="Forgot Password">
			  
			  <p>New to the site?<a href="#" class="toogleForms">Sign Up</a></p>
			  
			</form>
			
			<form id="signUpForm" method="POST">
				<div class="form-group">
				<label for="Role">Role</label>
				<select id="role2" name="role2" class="form-control">
					<option value="Seller">Seller</option>
					<option selected value="Customer">Customer</option>
				</select>
			   </div>
				  <div class="form-row">
					<div class="form-group col-md-6">
					  <label for="inputEmail4">Email</label>
					  <input type="email" name="email" class="form-control" id="inputEmail4" required>
					</div>
					<div class="form-group col-md-6">
					  <label for="inputPassword4">Password</label>
					  <input name="password" type="password" class="form-control" id="inputPassword4">
					</div>
				  </div>
				  <div class="form-group">
					<label for="inputAddress">Address</label>
					<input type="text" name="address" class="form-control" id="inputAddress" placeholder="W.No. 6, H.No. 287, Behind Old Microwave Station">
				  </div>
				  <div class="form-group">
					<label for="inputAddress2">Address 2</label>
					<input type="text" name="address2" class="form-control" id="inputAddress2" placeholder="W.No. 6, H.No. 287, Behind Old Microwave Station">
				  </div>
				  <div class="form-row">
					<div class="form-group col-md-6">
					  <label for="inputCity">City</label>
					  <input type="text" name="city" class="form-control" id="inputCity">
					</div>
					<div class="form-group col-md-4">
					  <label for="inputState">State</label>
					  <select id="inputState" name="state" class="form-control">
						<option selected>Choose...</option>
						<option value="Andhra Pradesh">Andhra Pradesh</option>
						<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
						<option value="Arunachal Pradesh">Arunachal Pradesh</option>
						<option value="Assam">Assam</option>
						<option value="Bihar">Bihar</option>
						<option value="Chandigarh">Chandigarh</option>
						<option value="Chhattisgarh">Chhattisgarh</option>
						<option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
						<option value="Daman and Diu">Daman and Diu</option>
						<option value="Delhi">Delhi</option>
						<option value="Lakshadweep">Lakshadweep</option>
						<option value="Puducherry">Puducherry</option>
						<option value="Goa">Goa</option>
						<option value="Gujarat">Gujarat</option>
						<option value="Haryana">Haryana</option>
						<option value="Himachal Pradesh">Himachal Pradesh</option>
						<option value="Jammu and Kashmir">Jammu and Kashmir</option>
						<option value="Jharkhand">Jharkhand</option>
						<option value="Karnataka">Karnataka</option>
						<option value="Kerala">Kerala</option>
						<option value="Madhya Pradesh">Madhya Pradesh</option>
						<option value="Maharashtra">Maharashtra</option>
						<option value="Manipur">Manipur</option>
						<option value="Meghalaya">Meghalaya</option>
						<option value="Mizoram">Mizoram</option>
						<option value="Nagaland">Nagaland</option>
						<option value="Odisha">Odisha</option>
						<option value="Punjab">Punjab</option>
						<option value="Rajasthan">Rajasthan</option>
						<option value="Sikkim">Sikkim</option>
						<option value="Tamil Nadu">Tamil Nadu</option>
						<option value="Telangana">Telangana</option>
						<option value="Tripura">Tripura</option>
						<option value="Uttar Pradesh">Uttar Pradesh</option>
						<option value="Uttarakhand">Uttarakhand</option>
						<option value="West Bengal">West Bengal</option>
					  </select>
					</div>
					<div class="form-group col-md-2">
					  <label for="inputZip">Zip</label>
					  <input type="text" name="zip" class="form-control" id="inputZip">
					</div>
				  </div>
				  
				  <input name="signUpSubmit" name="signUpSubmit" type="submit" class="btn  btn-outline-light sButton" value="Sign Up">
				  
				  <p>Already have a account?<a href="#" class="toogleForms">Sign In</a></p>
				 
			</form>
			
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-outline-light sButton" data-dismiss="modal">Close</button>
		  </div>
		</div>
	  </div>
	</div>