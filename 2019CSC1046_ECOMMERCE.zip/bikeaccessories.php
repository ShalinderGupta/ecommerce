<?php

	include("connection.php");

	$logId="";
	$error="";
	
	if(!isset($_SESSION['id']))
	{
		
		$_SESSION['id']=$_COOKIE['id'];
	}
	
	$logId=$_SESSION['id'];

			
	$query="SELECT email FROM users WHERE id='".$logId."' LIMIT 1";
			
	$result=mysqli_query($link,$query);
			
	$row= mysqli_fetch_array($result);
	
	$logId=$row['email'];
	
	//echo $logId;
	
	if($_SESSION['id']<0)
	{
		$error="";
		$logId="";
		$logout="";
	
		if(array_key_exists("logout",$_POST))
		{
			unset($_SESSION);
			setcookie("id","",time()-60*60);
			
			$_COOKIE["id"]="";
			
			header("Location: index.php");
			
		}
		
		if(array_key_exists("signUpSubmit",$_POST))
		{
			
			if(!$_POST['email'])
			{
				$error.="An E-mail Address is Required!<br>";
			}
			if(!$_POST['password'])
			{
				$error.="Password is Required!<br>";
			}
			if(!$_POST['address'])
			{
				$error.="Address is Required!<br>";
			}
			if(!$_POST['address2'])
			{
				$error.="Address is Required!<br>";
			}
			if(!$_POST['city'])
			{
				$error.="City is Required!<br>";
			}
			if(!$_POST['state'])
			{
				$error.="State is Required!<br>";
			}
			if(!$_POST['zip'])
			{
				$error.="Zip is Required!<br>";
			}
			if(!$_POST['role2'])
			{
				$error.="Role is Required!<br>";
			}
			if($error!="")
			{
				$error="<p>There were error(s) in your form:</p>".$error;
			}
			else
			{
				$email=mysqli_real_escape_string($link,$_POST['email']);
				$query="SELECT id FROM users WHERE email='".$email."' LIMIT 1";
				
				$result=mysqli_query($link,$query);
				
				if(mysqli_num_rows($result)>0)
				{
					$error="That email is taken.";
				}else
				{
					$email=mysqli_real_escape_string($link,$_POST['email']);
					$password=mysqli_real_escape_string($link,$_POST['password']);
					$address=mysqli_real_escape_string($link,$_POST['address']);
					$address2=mysqli_real_escape_string($link,$_POST['address2']);
					$city=mysqli_real_escape_string($link,$_POST['city']);
					$state=mysqli_real_escape_string($link,$_POST['state']);
					$zip=mysqli_real_escape_string($link,$_POST['zip']);
					$role=mysqli_real_escape_string($link,$_POST['role2']);
					
					$query="INSERT INTO users (email,password,address,address2,city,state,zip,role) VALUES ('".$email."','".$password."','".$address."','".$address2."','".$city."','".$state."','".$zip."','".$role."')";
					
					if(mysqli_query($link, $query))
					{
						setcookie("id", mysqli_insert_id($link), time()+60*60);
						
						if(!isset($_COOKIE['id']))
						{
							echo "Cookie is not set";
						}
						else
						{
							echo "Cookie is set";
						}
						$query="UPDATE users SET password='".md5(md5(mysqli_insert_id($link)).$_POST['password'])."'WHERE id=".mysqli_insert_id($link)." LIMIT 1"; 
						//mysqli_insert_id() will the take the id of the inserted row and the md5 it and it would then append to the password they ahve put in, and it wpu;d md5 that and put as the password of the user
						
						mysqli_query($link, $query);
						
						$_SESSION['id']= mysqli_insert_id($link);
						
						$logId=$_SESSION['id'];
					}else
					{
						$error="<p>Could not sign you up please try again later</p>";
					}
				}
			}
		}
		
		
		if(array_key_exists("loginSubmit",$_POST))
		{
			if(!$_POST['email'])
			{
				$error.="An E-mail Address is Required!<br>";
			}
			if(!$_POST['password'])
			{
				$error.="Password is Required!<br>";
			}

			if($error!="")
			{
				$error="<p>There were error(s) in your form:</p>".$error;
			}
			else
			{
				$email=mysqli_real_escape_string($link,$_POST['email']);
				
				$query="SELECT * FROM users WHERE email='".$email."' LIMIT 1";
				
				$result=mysqli_query($link,$query);
				
				$row= mysqli_fetch_array($result);
				
				if(isset($row))
				{
					$hashedPassword=md5(md5($row['id']).$_POST['password']);
					
					//echo $row['password'];
					
					if($hashedPassword == $row['password'])
					{
						$_SESSION['id']=$row['id'];
						setcookie("id", $_SESSION['id'], time()+60*60);
						if(!isset($_COOKIE['id']))
						{
							echo "Cookie is not set";
						}
						else
						{
							echo "Cookie is set";
							echo $_COOKIE['id'];
						}
						$_SESSION['email']=$row['email'];
						$logId=$_SESSION['email'];
						
					}else
					{
						$error.="Incorrect password<br>";
					}
				}
			
			}
		}
	
	}
	
	if($_GET["id"])
	{
		$id=$_SESSION['id'];
	
		$query="SELECT * FROM products WHERE id=".$id." LIMIT 1";
		
		$result=mysqli_query($link,$query);
		
		$row= mysqli_fetch_array($result);
		
		$cId=$_SESSION['id'];
		
		$title=$row['pName'];
		$price=$row['pPrice'];
		//$image=$row['pImage'];
		$quantity=$_POST['quantity'];
		
		//$query="SELECT * FROM users WHERE";
		
		$query="INSERT INTO cart (id,title,price,quantity,image) VALUES('".$cId."','".$title."','".$price."','".$quantity."')";//,'".$image."'
		
		//$result=mysqli_query($link, $query);
		
		if(mysqli_query($link, $query))
		{
			echo "Query Successful";
			//echo '<script type="text/javascript">window.location="bikeaccessories.php"</script>';
		}
		else
		{
			echo "Some error has occured";
		}
	}
	else
	{
		echo "No post object";
	}
	
	
	include("header.php");
?>

<div class="row">
	<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
	<h3 align="center">Bike Accessories</h3>
	</div>
</div>

<div class="row">
	
	<?php
		$query="SELECT * FROM products ORDER BY id ASC";
		
		$result=mysqli_query($link,$query);
		
		if(mysqli_num_rows($result)>0)
		{
			while($row=mysqli_fetch_array($result))
			{
	?>
	<div class="col-lg-4 col-sm-6 col-md-6 col-xs-6 border">
		
			
			<form id="cartForm" method="POST" action="bikeaccessories.php?action=add&id=<?php echo $row["id"]; ?>">
			<div class="product">
				<img src="data:image/jpg;charset=utf8;base64,<?php echo base64_encode($row['pImage']);?>" height="250" width="250">
				<br>
				<input type="text" class="displayPName" readonly value="<?php echo $row['pName'];?>">
				<br>
				<input type="text" class="displayPName" readonly value="<?php echo 'Rs.'.$row['pPrice'];?>">
				<br>
				<label for="quantity"class="displayPName">Quantity:</label>
				<input type="number" name="quantity" id="quantity" class="displayPName" value="1">
				<br>
				<button name="addToCart" role="button" id="addToCart" class="displayPName btn btn-outline-light my-2 my-sm-0 color-white">Add to Cart</button>
			</div>
			</form>
			
		
	</div>	
	<?php
			
		}
				
		}
	?>

	

	
	
</div>